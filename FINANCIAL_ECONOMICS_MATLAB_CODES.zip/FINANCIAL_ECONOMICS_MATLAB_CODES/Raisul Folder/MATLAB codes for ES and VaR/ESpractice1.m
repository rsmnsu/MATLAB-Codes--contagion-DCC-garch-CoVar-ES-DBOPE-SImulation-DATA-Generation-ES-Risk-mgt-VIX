clc
clear
%% Load index and convert to returns 
load datasmallsd
r = datasmallsd([1:100000],1);
T = length(r);
t = 1000;
%% Declare storage
conditionalvariance=[];
%p= [0.5, 0,1, 0.05, 0.025,0.01, 0.001];
%% Estimate Conditional variances
q = 0.05;
bPoE= 0.1;
VarMdl = garch(1,1)
Mdl = arima('ARLags',1,'Variance',VarMdl)
EstMdl = estimate(Mdl,r);
[res,v,logL] = infer(EstMdl,r);
conditionalvariance=[conditionalvariance,v];
Sigma=conditionalvariance;

%% Estimate dynamic ES and dynamic BpoE
ESdynamic=[];
Vardynamic=[];
progressbar

for J= t:T;
    r1 = r(J-t+1:J);
    ES=hNormalVaRES(Sigma(J),q,r1)
    ESdynamic=[ESdynamic,ES];
    disp(J);
    disp('');
    progressbar(J/T)
end
%save ES2.mat ES Var_Normal EST5 EST10 Var_T10 Var_T5
ESdynamic1=ESdynamic';
%% Phase 2
r = datasmallsd([1:100000],2);
T = length(r);
t = 1000;
conditionalvariance=[];
q = 0.05;
bPoE= 0.1;
VarMdl = garch(1,1)
Mdl = arima('ARLags',1,'Variance',VarMdl)
EstMdl = estimate(Mdl,r);
[res,v,logL] = infer(EstMdl,r);
conditionalvariance=[conditionalvariance,v];
Sigma=conditionalvariance;
ESdynamic=[];
Vardynamic=[];
progressbar
for J= t:T;
    r1 = r(J-t+1:J);
    ES=hNormalVaRES(Sigma(J),q,r1)
    ESdynamic=[ESdynamic,ES];
    disp(J);
    disp('');
    progressbar(J/T)
end
%save ES2.mat ES Var_Normal EST5 EST10 Var_T10 Var_T5
ESdynamic2=ESdynamic';

%% Phase 2
r = datasmallsd([1:100000],3);
T = length(r);
t = 1000;
conditionalvariance=[];
q = 0.05;
bPoE= 0.1;
VarMdl = garch(1,1)
Mdl = arima('ARLags',1,'Variance',VarMdl)
EstMdl = estimate(Mdl,r);
[res,v,logL] = infer(EstMdl,r);
conditionalvariance=[conditionalvariance,v];
Sigma=conditionalvariance;
ESdynamic=[];
Vardynamic=[];
progressbar
for J= t:T;
    r1 = r(J-t+1:J);
    ES=hNormalVaRES(Sigma(J),q,r1)
    ESdynamic=[ESdynamic,ES];
    disp(J);
    disp('');
    progressbar(J/T)
end
%save ES2.mat ES Var_Normal EST5 EST10 Var_T10 Var_T5
ESdynamic3=ESdynamic';

%% Plot
plot(ESdynamic1(ESdynamic1~=0)) 
hold on
plot(ESdynamic2(ESdynamic2~=0))
plot(ESdynamic3(ESdynamic3~=0))
hold off

%% local function for Normally distributed ES 
function ES = hNormalVaRES(Sigma,p,x)
    % Compute VaR and ES for normal distribution
    % See [4] for technical details
    mu = mean(x);   
    ES = mu + sqrt(Sigma)*normpdf(norminv(p))./p;
end
