#install.packages("MASS")
library("MASS")
#install.packages("writexl")
library(writexl)
#set.seed(98989)
mu<-c(0,0,0)
K<-c(0.9,0.95,0.86) #High variance- for low variance use below 0.3, for mid variance use between 0,5-0,6
Sigma<- K%*%t(K)
sigma<-matrix(c(0.91,0.95,0, 0.87, 0, 0.82, 0, 0.81, 0.98), 3,3) #High variance
#data1<-var(mvrnorm(n=100000, mu, Sigma, empirical = TRUE))
data1<-mvrnorm(n=100000, mu, Sigma, empirical = TRUE)
install.packages("risk")
install.packages("cvar")
library(cvar)
install.packages("quantreg")
library(quantreg)
srisk1<-srisk(data1, mu=0, lambda = 1e+08, alpha = 0.05, eps = 1e-04)

