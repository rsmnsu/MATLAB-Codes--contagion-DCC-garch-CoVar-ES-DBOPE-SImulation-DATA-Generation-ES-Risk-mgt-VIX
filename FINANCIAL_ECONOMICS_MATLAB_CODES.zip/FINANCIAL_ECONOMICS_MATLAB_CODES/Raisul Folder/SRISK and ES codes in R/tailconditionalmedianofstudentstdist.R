install.packages("Risk")
alpha <- seq(0.01, 0.99, 0.01)
y1 <- tcm("t", alpha, df = 1)
y2 <- tcm("t", alpha, df = 2)
y3 <- tcm("t", alpha, df = 5)
y4 <- tcm("t", alpha, df = 10)
xrange <- range(alpha) 
yrange <- range(0, 20)
# take the data into matlab and draw plot
plot(alpha, y1, type = "l", xlab = expression(alpha),
        + ylab = "TCM", col = "black", xlim = xrange, ylim = yrange) 
par(new = TRUE)

plot(alpha, y2, type = "l", xlab = "", ylab = "",
        + col = "red", xlim = xrange, ylim = yrange) 
par(new = TRUE)

plot(alpha, y3, type = "l", xlab = "", ylab = "",
        + col = "blue", xlim = xrange, ylim = yrange) 
par(new = TRUE)

plot(alpha, y4, type = "l", xlab = "", ylab = "",
        + col = "brown", xlim = xrange, ylim = yrange) 
legend(0.5, 20, 
       + legend = c("df = 1", "df = 2", "df = 5", "df = 10"),                                                 
        + col = c("black", "red", "blue", "brown"), lty = 1)

